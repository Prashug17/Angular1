import { Component } from '@angular/core';
import { EmployeeService } from './employee.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers:[EmployeeService]
})
export class AppComponent {
  constructor(private empserv:EmployeeService){
    
  }
  empdata:{ename:string, dept:string,gender:string,age:number,location:string,email:string}[]=[];
}
