import { Component,OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-display-employee-details',
  templateUrl: './display-employee-details.component.html',
  styleUrls: ['./display-employee-details.component.css']
})
export class DisplayEmployeeDetailsComponent implements OnInit{

  constructor(private emp:EmployeeService){}
  emp1!:{ename:string, dept:string,gender:string,age:number,location:string,email:string;};
  ngOnInit(): void {
    this.emp.OnDisplayDetailsClicked.subscribe((data:{ename:string, dept:string,gender:string,age:number,location:string,email:string})=>{
      this.emp1=data;
    })
  }

}
