import { Component,OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employee-info',
  templateUrl: './employee-info.component.html',
  styleUrls: ['./employee-info.component.css']
})
export class EmployeeInfoComponent implements OnInit {

  constructor(private emp:EmployeeService){}
  employeesinfo:{ename:string, dept:string,gender:string,age:number,location:string,email:string}[]=[];
  ngOnInit(): void {
    this.employeesinfo=this.emp.employees;
  }

  showDetails(emp:{ename:string, dept:string,gender:string,age:number,location:string,email:string}){
    this.emp.showEmpDetails(emp);
  }

}
