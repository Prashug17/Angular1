import { Component } from '@angular/core';
import { FlightserviceService } from '../flightservice.service';

@Component({
  selector: 'app-add-flight',
  templateUrl: './add-flight.component.html',
  styleUrls: ['./add-flight.component.scss']
})
export class AddFlightComponent {
  constructor(private flight: FlightserviceService) { 

  }
  getFlightFormData(data:any){
    this.flight.addFlight(data).subscribe((result)=>{
      console.log(result);
    })
  }
}
