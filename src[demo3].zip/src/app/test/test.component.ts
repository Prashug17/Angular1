import { Component } from '@angular/core';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent {
  a=10;
  b=20;
  name="Bhushan";

  getName(){
    return this.name;
  }
  daysInWeek=['Monday','Tuesday','Wednesday'];

  name1:any|undefined;
  name2:string|undefined;
}
