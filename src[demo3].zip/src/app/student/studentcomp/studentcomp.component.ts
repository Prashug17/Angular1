import { Component } from '@angular/core';

@Component({
  selector: 'app-studentcomp',
  templateUrl: './studentcomp.component.html',
  styleUrls: ['./studentcomp.component.css']
})
export class StudentcompComponent {
 
}
