import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StudentcompComponent } from './studentcomp/studentcomp.component';





@NgModule({
  declarations: [
    StudentcompComponent
  ],
  imports: [
    CommonModule
  ],

  exports:[StudentcompComponent],

})
export class StudentModule { }
