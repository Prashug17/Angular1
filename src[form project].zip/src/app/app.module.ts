import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegformComponent } from './regform/regform.component';
import { SigninComponent } from './signin/signin.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { HomeComponent } from './home/home.component';
import { HttpClientModule } from '@angular/common/http';
import { UserserviceService } from './userservice.service';
import { StudentService } from './student.service';
import { UserComponent } from './user/user.component';
import { UserdetailsComponent } from './userdetails/userdetails.component';
import { PrimeuserComponent } from './user/primeuser/primeuser.component';
import { AuthGuard } from './auth.guard';

@NgModule({
  declarations: [
    AppComponent,
    RegformComponent,
    SigninComponent,
    PagenotfoundComponent,
    HomeComponent,
    UserComponent,
    UserdetailsComponent,
    PrimeuserComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
    
  ],
  providers: [UserserviceService,StudentService,AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
