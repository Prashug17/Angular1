import { Component } from '@angular/core';
import { UserserviceService } from 'src/app/userservice.service';

@Component({
  selector: 'app-component1',
  templateUrl: './component1.component.html',
  styleUrls: ['./component1.component.css']
})
export class Component1Component {
  userData:any;
  constructor(private users:UserserviceService){
    // let userdata= this.user.getUserData();
    // console.log(userdata);
    this.users.getUserData().subscribe(data=>{
      console.log(data);
      this.userData=data;
    })
  }
}
