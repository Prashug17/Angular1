import { Component } from '@angular/core';
import { StudentService } from 'src/app/student.service';

@Component({
  selector: 'app-component2',
  templateUrl: './component2.component.html',
  styleUrls: ['./component2.component.css']
})
export class Component2Component {
  stdData:any;
  constructor(private std:StudentService){
    
    this.std.getstdData().subscribe(data1=>{
      console.log(data1);
      this.stdData=data1;
  })
}
}
