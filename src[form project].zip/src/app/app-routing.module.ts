import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegformComponent } from './regform/regform.component';
import { SigninComponent } from './signin/signin.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { HomeComponent } from './home/home.component';
import { UserComponent } from './user/user.component';
import { UserdetailsComponent } from './userdetails/userdetails.component';
import { PrimeuserComponent } from './user/primeuser/primeuser.component';
import { AuthGuard } from './auth.guard';

const routes: Routes = [
  {path:'page',component:PagenotfoundComponent},
  {path:'home',component:HomeComponent},
  {path:'regform',component:RegformComponent},
  {path:'sigform',component:SigninComponent,canActivate:[AuthGuard]},
  {path:'lazymodule',loadChildren:()=>import('./lazymodule/lazymodule.module').then(m=>m.LazymoduleModule)},
  {path:'user',children:[
    {path:'',component:UserComponent},
    {path:'prime',component:PrimeuserComponent}
  ]},
  {path:'userdetails/:id',component:UserdetailsComponent},
  {path:'**',component:PagenotfoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
