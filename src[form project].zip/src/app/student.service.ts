import { Injectable } from '@angular/core';
import{HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  constructor(private http:HttpClient) { }
  getstdData(){
    let url='http://localhost:9090/api/student';
    return this.http.get(url);
  }

  poststdData(input:any){
    let url='http://localhost:9090/api/student';
    return this.http.post(url,input);
  }

}
