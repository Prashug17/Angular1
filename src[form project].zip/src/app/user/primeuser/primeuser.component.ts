import { Component } from '@angular/core';

@Component({
  selector: 'app-primeuser',
  templateUrl: './primeuser.component.html',
  styleUrls: ['./primeuser.component.css']
})
export class PrimeuserComponent {

}
