import { Component } from '@angular/core';
import{FormGroup,FormControl,Validators} from '@angular/forms';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent {
  signform=new FormGroup({
    un1:new FormControl('',[Validators.required]),
    ps1:new FormControl('',[Validators.minLength(3),Validators.maxLength(8),Validators.required])
  })

  get un(){
    return this.signform.get('un1');
  }

  get ps(){
    return this.signform.get('ps1');
  }

  signin(){
    console.log("this.signform.value")
  }
}
