import { Component ,OnInit} from '@angular/core';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  myObservable= new Observable((observer)=>{
    observer.next("abc");
    observer.next("def");
    observer.next("ijk");
    observer.next("lmn");
  });

  ngOnInit(): void {
    // console.log(this.myObservable);
    this.myObservable.subscribe((data)=>{
      console.log(data);
    })
  }
  
}
