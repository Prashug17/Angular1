import { TestBed } from "@angular/core/testing";
import { AppComponent } from "./app.component";
import{addition,subtraction} from 'src/calculator';
import { GetlengthPipe } from "./getlength.pipe";

describe('AppComponent',()=>{
    beforeEach(()=>{
        console.log('BeforeEach is called')
    })
    it('myFirstTest',()=>{
        expect(20).toBe(addition(10,10));
        expect(2).toBe(subtraction(6,4));
    })

    let length=new GetlengthPipe();
    it('Testing get length pipe',()=>{
        expect(5).toBe(length.transform('Prash'))
    })
    afterAll(()=>{
        console.log('AfterAll is called')
    })
    })
