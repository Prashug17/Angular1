function addition(num1:number,num2:number):number{
    return num1+num2;
}
function subtraction(num1:number,num2:number):number{
    return num1-num2;
}
export{addition,subtraction}