import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegformComponent } from './regform/regform.component'; 
import { SiginComponent } from './sigin/sigin.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
  {path:'', component:HomeComponent},
  {path:'home', component:HomeComponent},
  {path: 'regform', component:RegformComponent},
  {path: 'sign', component:SiginComponent},
  {path:'about', component:PagenotfoundComponent},
  {path:'lazymodule', loadChildren:()=>import('./lazymodule/lazymodule.module').
  then(mod=>mod.LazymoduleModule)},
  {path: '**' ,component:PagenotfoundComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
