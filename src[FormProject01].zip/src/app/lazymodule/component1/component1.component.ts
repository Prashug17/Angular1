import { Component } from '@angular/core';
import { UserdataService } from 'src/app/userdata.service';

@Component({
  selector: 'app-component1',
  templateUrl: './component1.component.html',
  styleUrls: ['./component1.component.css']
})
export class Component1Component {
  userData:any;
  constructor(private users:UserdataService){
    // let userdata = this.users.getUserData();
    // console.log(userdata);
    this.users.getUserData().subscribe(data=>{
      console.log(data)
      this.userData=data;
    })
  }


}
