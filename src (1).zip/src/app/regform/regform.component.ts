import { Component } from '@angular/core';

@Component({
  selector: 'app-regform',
  templateUrl: './regform.component.html',
  styleUrls: ['./regform.component.css']
})
export class RegformComponent {

  regData:any
  regValues!:{fname:string,lname:string,email:string,password:string}
  submit(Data:any){
    console.log(Data.value);
    // console.log(regData)
    this.regData=Data.value
    // console.log(this.regData.fname)
    this.regValues={fname:this.regData.fname,lname:this.regData.lname,email:this.regData.email,password:this.regData.email}
  }

}
