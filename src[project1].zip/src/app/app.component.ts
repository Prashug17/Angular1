import { Component } from '@angular/core';
import { CustomerserviceService } from './customerservice.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor(private custser:CustomerserviceService){}
  title = 'project1';
  dataforchild="Hello child";

  empDetails=[
    {id:10,name:"john"},
    {id:11,name:"dev"},
  ]


  data:any;
  parentFunction(myData:any){
    this.data=myData;
  }

  getData(){
    this.custser.testMethod();
  }

}
