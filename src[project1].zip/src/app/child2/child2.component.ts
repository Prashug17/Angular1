import { Component ,Output,EventEmitter} from '@angular/core';

@Component({
  selector: 'app-child2',
  templateUrl: './child2.component.html',
  styleUrls: ['./child2.component.css']
})
export class Child2Component {
  @Output() parentFunction:EventEmitter<any>=new EventEmitter();

  sendDataToParent(){
    let emp=[
      {id:101,name:"John"}
      ]
    this.parentFunction.emit(emp)
  }
}
