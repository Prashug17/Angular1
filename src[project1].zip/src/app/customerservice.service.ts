import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CustomerserviceService {

  constructor() { }

  testMethod(){
    let emp1:any
    emp1=[
      {id:101,name:"abc"}
    ]
  }
}
